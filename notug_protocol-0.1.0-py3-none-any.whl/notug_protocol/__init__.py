"""NoTUG: local mutation governance for coding agents."""

from .brand import VERSION

__all__ = ["VERSION"]
