"""Optional Leucoform desktop companion for the NoTUG governance engine."""

from .codex import CodexInstallation, build_codex_command, discover_codex
from .state import OrbAppearance, OrbState, appearance_for

__all__ = [
    "CodexInstallation",
    "OrbAppearance",
    "OrbState",
    "appearance_for",
    "build_codex_command",
    "discover_codex",
]
