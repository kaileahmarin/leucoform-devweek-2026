"""End-to-end local Git workflow tests."""
