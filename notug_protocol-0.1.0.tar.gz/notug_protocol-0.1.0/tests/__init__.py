"""NoTUG test suite."""
