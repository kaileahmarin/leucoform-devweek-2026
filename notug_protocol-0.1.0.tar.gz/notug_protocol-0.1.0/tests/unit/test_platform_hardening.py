from __future__ import annotations

import io
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from notug_protocol import doctor, sessions
from notug_protocol.brand import HOME_ENVIRONMENT_VARIABLE
from notug_protocol.doctor import diagnose
from notug_protocol.errors import NoTugError
from notug_protocol.grants import _validation_commands
from notug_protocol.process import run_sanitized_process
from notug_protocol.util import data_home, safe_git_path


class DataHomeTests(unittest.TestCase):
    def test_relative_notug_home_is_rejected(self) -> None:
        for value in ("relative-vault", " ", "C:drive-relative"):
            with self.subTest(value=repr(value)):
                with (
                    patch.dict(
                        os.environ,
                        {HOME_ENVIRONMENT_VARIABLE: value},
                        clear=False,
                    ),
                    self.assertRaises(NoTugError) as caught,
                ):
                    data_home()

                self.assertEqual(caught.exception.code, "VAULT_HOME_INVALID")

    def test_absolute_and_expanded_home_overrides_are_accepted(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-home-") as temporary:
            absolute = Path(temporary).resolve()
            with patch.dict(
                os.environ,
                {HOME_ENVIRONMENT_VARIABLE: str(absolute)},
                clear=False,
            ):
                self.assertEqual(data_home(), absolute)

        expanded = Path("~").expanduser()
        self.assertTrue(expanded.is_absolute())
        with patch.dict(os.environ, {HOME_ENVIRONMENT_VARIABLE: "~"}, clear=False):
            self.assertEqual(data_home(), expanded.resolve())


class PortableGitPathTests(unittest.TestCase):
    def test_control_bidi_and_surrogate_code_points_are_rejected(self) -> None:
        unsafe_characters = {
            "tab": "\t",
            "newline": "\n",
            "c0": "\x1f",
            "delete": "\x7f",
            "c1": "\x85",
            "bidi": "\u202e",
            "surrogateescape": "\udcff",
            "lone_surrogate": "\ud800",
        }

        for label, character in unsafe_characters.items():
            with self.subTest(label=label):
                safe, reason = safe_git_path(f"src/{character}name.py")

                self.assertIs(safe, False)
                self.assertEqual(
                    reason,
                    "control, directionality, or surrogate character",
                )


class DoctorPermissionReportingTests(unittest.TestCase):
    def test_writability_probe_does_not_claim_confidential_permissions(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-doctor-") as temporary:
            root = Path(temporary)
            repository = SimpleNamespace(root=root / "repository")
            repository.root.mkdir()
            vault = Mock()
            vault.root = root / "prospective-vault"
            vault.ensure_external.return_value = None

            with (
                patch("notug_protocol.doctor.git_version", return_value="git version test"),
                patch("notug_protocol.doctor.discover_repository", return_value=repository),
                patch("notug_protocol.doctor.is_clean", return_value=True),
                patch("notug_protocol.doctor.worktree_list", return_value=[]),
            ):
                report = diagnose(repository.root, vault=vault)

        findings = {finding["code"]: finding for finding in report["findings"]}
        self.assertNotIn("VAULT_PERMISSIONS_OK", findings)
        self.assertEqual(findings["VAULT_WRITABILITY_OK"]["severity"], "info")
        self.assertEqual(
            findings["VAULT_CONFIDENTIALITY_NOT_ASSESSED"]["severity"],
            "info",
        )
        self.assertIn(
            "not assessed",
            findings["VAULT_CONFIDENTIALITY_NOT_ASSESSED"]["message"].casefold(),
        )

    def test_non_directory_vault_ancestor_is_not_reported_writable(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-doctor-vault-file-") as temporary:
            root = Path(temporary)
            repository = SimpleNamespace(root=root / "repository")
            repository.root.mkdir()
            blocked_ancestor = root / "vault-parent"
            blocked_ancestor.write_bytes(b"not a directory\n")
            vault = Mock()
            vault.root = blocked_ancestor / "v1"
            vault.ensure_external.return_value = None

            with (
                patch("notug_protocol.doctor.git_version", return_value="git version test"),
                patch("notug_protocol.doctor.discover_repository", return_value=repository),
                patch("notug_protocol.doctor.is_clean", return_value=True),
                patch("notug_protocol.doctor.worktree_list", return_value=[]),
            ):
                report = diagnose(repository.root, vault=vault)

        findings = {finding["code"]: finding for finding in report["findings"]}
        self.assertNotIn("VAULT_WRITABILITY_OK", findings)
        self.assertEqual(findings["VAULT_PERMISSION_DENIED"]["severity"], "error")
        self.assertFalse(report["ok"])


class WindowsProcessBoundaryTests(unittest.TestCase):
    @unittest.skipUnless(os.name == "nt", "Windows batch parsing is platform-specific")
    def test_direct_batch_command_is_refused_before_metacharacter_interpretation(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-batch-boundary-") as temporary:
            root = Path(temporary)
            batch = root / "probe.cmd"
            marker = root / "injected.txt"
            batch.write_bytes(b"@echo off\r\necho ARGS=[%*]\r\n")

            with self.assertRaisesRegex(OSError, "batch"):
                run_sanitized_process(
                    [str(batch), "safe&echo.INJECTED>injected.txt"],
                    cwd=root,
                    env=os.environ,
                    runner=subprocess.run,
                    stdout=io.StringIO(),
                    stderr=io.StringIO(),
                )

            self.assertFalse(marker.exists())

    @unittest.skipUnless(os.name == "nt", "Windows batch parsing is platform-specific")
    def test_direct_batch_validation_reports_the_explicit_shell_requirement(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-batch-validation-") as temporary:
            root = Path(temporary)
            batch = root / "validation.cmd"
            batch.write_bytes(b"@echo off\r\nexit /b 0\r\n")

            with self.assertRaises(NoTugError) as caught:
                _validation_commands(root, [[str(batch)]])

        self.assertEqual(caught.exception.code, "WINDOWS_BATCH_REQUIRES_EXPLICIT_SHELL")
        self.assertEqual(caught.exception.details, {"index": 1})

    def test_existing_posix_vault_mode_is_reported_without_an_acl_claim(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-vault-mode-") as temporary:
            root = Path(temporary)

            private = doctor._vault_confidentiality_finding(  # type: ignore[attr-defined]
                root,
                platform_name="posix",
                mode=0o700,
            )
            exposed = doctor._vault_confidentiality_finding(  # type: ignore[attr-defined]
                root,
                platform_name="posix",
                mode=0o750,
            )
            windows = doctor._vault_confidentiality_finding(  # type: ignore[attr-defined]
                root,
                platform_name="nt",
                mode=0o700,
            )
            prospective = doctor._vault_confidentiality_finding(  # type: ignore[attr-defined]
                root / "not-created",
                platform_name="posix",
                mode=0o700,
            )

        self.assertEqual(private[0], "VAULT_ROOT_MODE_PRIVATE")
        self.assertEqual(private[1], "info")
        self.assertEqual(exposed[0], "VAULT_ROOT_MODE_EXPOSED")
        self.assertEqual(exposed[1], "warning")
        self.assertEqual(windows[0], "VAULT_CONFIDENTIALITY_NOT_ASSESSED")
        self.assertEqual(prospective[0], "VAULT_CONFIDENTIALITY_NOT_ASSESSED")


class CodexWorktreeBindingTests(unittest.TestCase):
    def test_node_codex_launch_gets_explicit_managed_worktree(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-codex-binding-") as temporary:
            worktree = Path(temporary).resolve()
            command = ["node.exe", r"C:\tools\@openai\codex\bin\codex.js", "exec", "prompt"]

            effective = sessions._bind_codex_worktree(command, worktree)

        self.assertEqual(
            effective,
            [command[0], command[1], "-C", str(worktree), "exec", "prompt"],
        )

    def test_matching_explicit_codex_worktree_is_preserved(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-codex-binding-") as temporary:
            worktree = Path(temporary).resolve()
            command = ["codex.exe", "exec", "--cd", str(worktree), "prompt"]

            self.assertEqual(sessions._bind_codex_worktree(command, worktree), command)

    def test_conflicting_codex_worktree_fails_before_launch(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-codex-binding-") as temporary:
            worktree = Path(temporary).resolve()
            other = worktree.parent / "protected-checkout"

            with self.assertRaises(NoTugError) as caught:
                sessions._bind_codex_worktree(
                    [
                        "node",
                        r"C:\tools\@openai\codex\bin\codex.js",
                        "--cd",
                        str(other),
                        "exec",
                        "prompt",
                    ],
                    worktree,
                )

        self.assertEqual(caught.exception.code, "AGENT_WORKSPACE_MISMATCH")

    def test_other_agent_commands_remain_unchanged(self) -> None:
        commands = (
            ["agent.exe", "--workspace", "caller-selected"],
            ["node.exe", r"C:\tools\unrelated\codex.js", "prompt"],
        )

        for command in commands:
            with self.subTest(command=command):
                self.assertEqual(sessions._bind_codex_worktree(command, Path.cwd()), command)


if __name__ == "__main__":
    unittest.main()
