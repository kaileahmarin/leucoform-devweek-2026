from __future__ import annotations

import json
import unittest

from notug_protocol.errors import NoTugError
from notug_protocol.resources import ResourceMeter, note_git_launch_attempt


class ResourceReceiptTests(unittest.TestCase):
    def test_meter_records_active_time_cpu_and_git_count(self) -> None:
        with ResourceMeter("op_measure_1", "repository.status") as meter:
            note_git_launch_attempt()
            note_git_launch_attempt()
        receipt = meter.receipt()
        payload = receipt.to_dict()

        self.assertGreaterEqual(payload["durations_seconds"]["notug_active_seconds"], 0)
        self.assertGreaterEqual(payload["process_cpu_seconds"], 0)
        self.assertEqual(payload["git_launch_attempt_count"], 2)
        self.assertTrue(payload["measurement_availability"]["git_launch_attempt_count"])

    def test_git_launch_note_is_no_op_without_active_meter(self) -> None:
        note_git_launch_attempt()

        with ResourceMeter("op_measure_unscoped", "repository.status") as meter:
            pass

        self.assertEqual(meter.receipt().git_launch_attempt_count, 0)

    def test_unavailable_values_are_explicit_not_zero_filled(self) -> None:
        with ResourceMeter("op_measure_2", "repository.status") as meter:
            pass
        payload = meter.receipt().to_dict()

        self.assertIsNone(payload["peak_working_set_bytes"])
        self.assertFalse(payload["measurement_availability"]["peak_working_set_bytes"])
        self.assertIsNone(payload["durations_seconds"]["agent_execution_seconds"])
        self.assertFalse(payload["measurement_availability"]["agent_execution_seconds"])
        self.assertIn("peak_working_set_not_sampled", payload["limitations"])

    def test_explicit_local_metrics_are_validated_and_serialized(self) -> None:
        with ResourceMeter("op_measure_3", "tug.generate") as meter:
            meter.record_metric("files_inspected", 4)
            meter.record_metric("bytes_inspected", 1024)
            meter.record_metric("protected_checkout_writes_detected", 0)
            meter.set_phase_duration("agent_execution_seconds", 2.5)
        payload = meter.receipt().to_dict()

        self.assertEqual(payload["files_inspected"], 4)
        self.assertTrue(payload["measurement_availability"]["files_inspected"])
        self.assertEqual(payload["durations_seconds"]["agent_execution_seconds"], 2.5)

    def test_serialization_has_no_field_for_private_paths_or_content(self) -> None:
        with ResourceMeter("op_measure_4", "verify") as meter:
            pass
        serialized = json.dumps(meter.receipt().to_dict(), sort_keys=True)
        fictional_private_path = r"X:\fixture\private-repository"

        self.assertNotIn(fictional_private_path, serialized)
        self.assertNotIn(json.dumps(fictional_private_path)[1:-1], serialized)
        self.assertNotIn("repository_name", serialized)
        self.assertNotIn("prompt", serialized)
        self.assertNotIn("diff", serialized)
        self.assertNotIn("commit", serialized)

    def test_path_like_operation_identifiers_are_rejected(self) -> None:
        with self.assertRaises(NoTugError) as caught:
            ResourceMeter("C:\\private\\operation", "verify")

        self.assertEqual(caught.exception.code, "RESOURCE_RECEIPT_INVALID")

    def test_nested_active_meters_are_rejected_without_hiding_outer_count(self) -> None:
        with ResourceMeter("op_outer", "verify") as outer:
            with self.assertRaises(NoTugError) as caught:
                ResourceMeter("op_inner", "verify").__enter__()
            note_git_launch_attempt()

        self.assertEqual(caught.exception.code, "RESOURCE_METER_INVALID")
        self.assertEqual(outer.receipt().git_launch_attempt_count, 1)

    def test_receipt_is_available_after_measured_block_raises(self) -> None:
        meter = ResourceMeter("op_exception", "verify")

        with self.assertRaisesRegex(RuntimeError, "synthetic failure"), meter:
            note_git_launch_attempt()
            raise RuntimeError("synthetic failure")

        receipt = meter.receipt()
        self.assertEqual(receipt.git_launch_attempt_count, 1)
        self.assertGreaterEqual(receipt.durations_seconds["notug_active_seconds"] or -1, 0)


if __name__ == "__main__":
    unittest.main()
