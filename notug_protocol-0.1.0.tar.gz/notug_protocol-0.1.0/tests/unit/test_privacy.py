from __future__ import annotations

import ast
import tomllib
import unittest
from pathlib import Path

from notug_protocol.brand import CLI_NAME, PACKAGE_NAME, VERSION


class OfflinePrivacyTests(unittest.TestCase):
    def test_runtime_source_imports_no_network_clients(self) -> None:
        source_root = Path(__file__).resolve().parents[2] / "src" / "notug_protocol"
        prohibited = {
            "aiohttp",
            "http.client",
            "httpx",
            "requests",
            "socket",
            "urllib.request",
        }
        found: list[str] = []
        for source in sorted(source_root.glob("*.py")):
            tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    modules = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    modules = [node.module or ""]
                else:
                    continue
                for module in modules:
                    if any(module == name or module.startswith(name + ".") for name in prohibited):
                        found.append(f"{source.name}:{module}")
        self.assertEqual(found, [])

    def test_runtime_package_has_no_required_dependencies(self) -> None:
        pyproject = (Path(__file__).resolve().parents[2] / "pyproject.toml").read_text(
            encoding="utf-8"
        )
        tree = tomllib.loads(pyproject)
        self.assertEqual(tree["project"]["dependencies"], [])

    def test_public_identity_registry_matches_packaging_metadata(self) -> None:
        pyproject = (Path(__file__).resolve().parents[2] / "pyproject.toml").read_text(
            encoding="utf-8"
        )
        tree = tomllib.loads(pyproject)

        self.assertEqual(tree["project"]["name"], PACKAGE_NAME)
        self.assertEqual(tree["project"]["version"], VERSION)
        self.assertEqual(tree["project"]["scripts"][CLI_NAME], "notug_protocol.cli:main")


if __name__ == "__main__":
    unittest.main()
