from __future__ import annotations

import json
import os
import tempfile
import tomllib
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from scripts.verify_release import (
    ProjectMetadata,
    VerificationError,
    _load_project_metadata,
    _sha256_record_value,
    _validate_archive_name,
    _verify_wheel_record,
    verify_clean_install,
    verify_wheel,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _tampered_metadata_wheel(destination: Path) -> tuple[Path, ProjectMetadata]:
    metadata = _load_project_metadata(PROJECT_ROOT)
    project = tomllib.loads((PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8"))[
        "project"
    ]
    dist_info = f"{metadata.normalized_name}-{metadata.version}.dist-info"
    headers = [
        "Metadata-Version: 2.4",
        f"Name: {metadata.name}",
        f"Version: {metadata.version}",
        "Summary: deliberately incorrect summary",
        f"Requires-Python: {metadata.requires_python}",
        f"Author: {', '.join(author['name'] for author in project['authors'])}",
        f"Keywords: {','.join(project['keywords'])}",
        f"License-Expression: {project['license']}",
        "License-File: LICENSE",
    ]
    headers.extend(f"Classifier: {value}" for value in project["classifiers"])
    for extra, requirements in project["optional-dependencies"].items():
        headers.append(f"Provides-Extra: {extra}")
        headers.extend(f'Requires-Dist: {value}; extra == "{extra}"' for value in requirements)
    files = {
        path.relative_to(PROJECT_ROOT / "src").as_posix(): path.read_bytes()
        for path in (PROJECT_ROOT / "src" / metadata.import_name).rglob("*")
        if path.is_file() and path.suffix in {".py", ".svg"}
    }
    files.update(
        {
            f"{dist_info}/METADATA": ("\n".join(headers) + "\n\n").encode(),
            f"{dist_info}/WHEEL": (
                b"Wheel-Version: 1.0\nRoot-Is-Purelib: true\nTag: py3-none-any\n\n"
            ),
            f"{dist_info}/entry_points.txt": (
                "[console_scripts]\n"
                + "\n".join(
                    f"{name} = {target}" for name, target in metadata.console_scripts.items()
                )
                + "\n\n[gui_scripts]\n"
                + "\n".join(f"{name} = {target}" for name, target in metadata.gui_scripts.items())
                + "\n"
            ).encode(),
            f"{dist_info}/licenses/LICENSE": (PROJECT_ROOT / "LICENSE").read_bytes(),
            f"{dist_info}/top_level.txt": f"{metadata.import_name}\n".encode(),
        }
    )
    record_name = f"{dist_info}/RECORD"
    files[record_name] = (
        "".join(
            f"{name},{_sha256_record_value(data)},{len(data)}\n"
            for name, data in sorted(files.items())
        )
        + f"{record_name},,\n"
    ).encode()
    wheel = destination / f"{metadata.normalized_name}-{metadata.version}-py3-none-any.whl"
    with zipfile.ZipFile(wheel, "w") as archive:
        for name, data in files.items():
            archive.writestr(name, data)
    return wheel, metadata


class ReleaseArchivePathTests(unittest.TestCase):
    def test_portable_archive_names_are_accepted(self) -> None:
        self.assertEqual(
            _validate_archive_name("notug_protocol-0.1.0/src/notug_protocol/cli.py"),
            ("notug_protocol-0.1.0", "src", "notug_protocol", "cli.py"),
        )

    def test_traversal_controls_links_and_windows_unsafe_names_are_rejected(self) -> None:
        rejected = (
            "/absolute/file.py",
            "C:/absolute/file.py",
            "root/../escape.py",
            "root\\windows\\path.py",
            "root/name\n.py",
            "root/name\u202e.py",
            "root/name\udcff.py",
            "root/CON.txt",
            "root/trailing.",
            "root/__pycache__/module.pyc",
            "root/.git/config",
        )
        for name in rejected:
            with self.subTest(name=repr(name)), self.assertRaises(VerificationError):
                _validate_archive_name(name)


class WheelRecordTests(unittest.TestCase):
    def test_record_hashes_and_sizes_cover_every_member(self) -> None:
        record_name = "sample-0.1.0.dist-info/RECORD"
        module_name = "sample/__init__.py"
        module = b'VERSION = "0.1.0"\n'
        record = (
            f"{module_name},{_sha256_record_value(module)},{len(module)}\n{record_name},,\n"
        ).encode()
        files = {module_name: module, record_name: record}

        _verify_wheel_record(files, record_name)

    def test_record_rejects_tampered_member_bytes(self) -> None:
        record_name = "sample-0.1.0.dist-info/RECORD"
        module_name = "sample/__init__.py"
        original = b"original\n"
        record = (
            f"{module_name},{_sha256_record_value(original)},{len(original)}\n{record_name},,\n"
        ).encode()

        with self.assertRaises(VerificationError):
            _verify_wheel_record(
                {module_name: b"tampered\n", record_name: record},
                record_name,
            )

    def test_wheel_metadata_must_match_all_declared_project_fields(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-metadata-verifier-") as temporary:
            wheel, metadata = _tampered_metadata_wheel(Path(temporary))

            with self.assertRaisesRegex(VerificationError, "Summary"):
                verify_wheel(wheel, PROJECT_ROOT, metadata)


class CleanInstallIsolationTests(unittest.TestCase):
    def test_pip_redirection_environment_is_removed_and_isolated_mode_is_used(self) -> None:
        metadata = _load_project_metadata(PROJECT_ROOT)
        calls: list[tuple[list[str], dict[str, str], Path]] = []

        def fake_venv_create(_builder: object, environment_root: Path) -> None:
            scripts = environment_root / ("Scripts" if os.name == "nt" else "bin")
            scripts.mkdir(parents=True)
            (scripts / ("python.exe" if os.name == "nt" else "python")).write_bytes(b"")
            (scripts / ("notug.exe" if os.name == "nt" else "notug")).write_bytes(b"")

        def fake_run(command: list[str], *, cwd: Path, environment: dict[str, str]) -> str:
            calls.append((command, environment, cwd))
            if command[-1] == "--version":
                return f"notug {metadata.version}\n"
            if command[-1] == "--help":
                return "usage: notug\n"
            if "-c" in command:
                purelib = cwd.parent / "venv" / "purelib"
                module = purelib / metadata.import_name / "__init__.py"
                return json.dumps({"module": str(module), "purelib": str(purelib)})
            if "demo" in command:
                return json.dumps(
                    {
                        "ok": True,
                        "demo": {
                            "protected_checkout_unchanged": True,
                            "receipt_tampering_detected": True,
                        },
                    }
                )
            return ""

        redirected = {
            "PIP_CONFIG_FILE": str(PROJECT_ROOT / "untrusted-pip.ini"),
            "PIP_PREFIX": str(PROJECT_ROOT / "redirected-prefix"),
            "PIP_TARGET": str(PROJECT_ROOT / "redirected-target"),
            "PIP_USER": "1",
        }
        with (
            patch.dict(os.environ, redirected, clear=False),
            patch("scripts.verify_release.venv.EnvBuilder.create", new=fake_venv_create),
            patch("scripts.verify_release._run", side_effect=fake_run),
        ):
            verify_clean_install(PROJECT_ROOT / "candidate.whl", PROJECT_ROOT, metadata)

        install_command, install_environment, _cwd = calls[0]
        self.assertIn("--isolated", install_command)
        self.assertFalse(
            any(key.casefold().startswith("pip_") for key in install_environment),
            install_environment,
        )


if __name__ == "__main__":
    unittest.main()
