from __future__ import annotations

import unittest
from dataclasses import replace

from notug_protocol.config import DEFAULT_POLICY, PolicyConfig, parse_policy_bytes
from notug_protocol.models import ChangeEntry
from notug_protocol.policy import (
    evaluate_policy,
    find_ignored_sensitive_paths,
    ignored_sensitive_paths,
)


def policy_config(**overrides: object) -> PolicyConfig:
    config = parse_policy_bytes(DEFAULT_POLICY)
    return replace(config, **overrides)


class PolicyEvaluationTests(unittest.TestCase):
    def test_classifies_all_structural_and_sensitive_change_categories(self) -> None:
        changes = [
            ChangeEntry(kind="delete", path=".env.production", old_size=20),
            ChangeEntry(
                kind="rename",
                path="deploy/run.sh",
                old_path="src/run.sh",
                old_mode="100644",
                new_mode="100755",
            ),
            ChangeEntry(kind="modify", path="assets/blob.bin", binary=True),
            ChangeEntry(
                kind="symlink",
                path="links/outside",
                new_mode="120000",
                symlink_target="../../outside",
                symlink_outside_workspace=True,
            ),
            ChangeEntry(kind="submodule", path="vendor/tool", submodule=True),
            ChangeEntry(kind="modify", path=".git/config"),
            ChangeEntry(kind="modify", path="nested/.git/config"),
            ChangeEntry(kind="modify", path=".notug/state.json"),
            ChangeEntry(kind="create", path="keys/id_ed25519", new_size=32),
            ChangeEntry(kind="modify", path="config/credentials.json"),
            ChangeEntry(kind="modify", path=".github/workflows/release.yml"),
            ChangeEntry(kind="modify", path="poetry.lock"),
        ]
        config = policy_config(expected_roots=["src", "tests"])

        result = evaluate_policy(changes, config)
        codes = {finding.code for finding in result.findings}

        self.assertTrue(
            {
                "BINARY_FILE",
                "CI_DEPLOYMENT",
                "CREDENTIAL_FILE",
                "DELETION",
                "ENVIRONMENT_FILE",
                "GIT_INTERNAL",
                "LOCKFILE",
                "MODE_CHANGE",
                "NOTUG_METADATA",
                "OUTSIDE_EXPECTED_ROOTS",
                "OUTSIDE_SYMBOLIC_LINK",
                "PRIVATE_KEY_FILE",
                "RENAME",
                "SUBMODULE_CHANGE",
                "SYMBOLIC_LINK",
                "UNSAFE_PATH",
            }.issubset(codes)
        )
        self.assertEqual(result.risk_summary["overall_severity"], "block")
        self.assertIs(result.risk_summary["blocked"], True)
        self.assertEqual(result.to_dict(), evaluate_policy(changes, config).to_dict())

    def test_thresholds_use_structural_file_and_byte_totals(self) -> None:
        config = policy_config(max_changed_files=1, max_changed_bytes=10)
        changes = [
            ChangeEntry(kind="create", path="src/a.bin", new_size=8),
            ChangeEntry(kind="modify", path="src/b.bin", byte_delta=4),
        ]

        result = evaluate_policy(changes, config)
        codes = {finding.code for finding in result.findings}

        self.assertIn("FILE_THRESHOLD_EXCEEDED", codes)
        self.assertIn("BYTE_THRESHOLD_EXCEEDED", codes)
        self.assertEqual(result.risk_summary["changed_files"], 2)
        self.assertEqual(result.risk_summary["changed_bytes"], 12)
        self.assertEqual(result.risk_summary["overall_severity"], "high")

    def test_outside_symlinks_and_removed_special_entries_are_classified(self) -> None:
        config = policy_config()
        findings = dict(config.findings)
        findings["outside_symbolic_links"] = "info"
        config = replace(config, findings=findings)
        changes = [
            ChangeEntry(
                kind="create",
                path="outside-link",
                new_mode="120000",
                symlink_outside_workspace=True,
            ),
            ChangeEntry(
                kind="delete",
                path="removed-link",
                old_mode="120000",
                new_mode="000000",
            ),
            ChangeEntry(
                kind="delete",
                path="removed-submodule",
                old_mode="160000",
                new_mode="000000",
            ),
        ]

        result = evaluate_policy(changes, config)
        by_code = {finding.code: finding for finding in result.findings}

        self.assertEqual(by_code["OUTSIDE_SYMBOLIC_LINK"].severity, "block")
        self.assertEqual(
            by_code["SYMBOLIC_LINK"].paths,
            ["outside-link", "removed-link"],
        )
        self.assertEqual(
            by_code["SUBMODULE_CHANGE"].paths,
            ["removed-submodule"],
        )

    def test_expected_roots_check_both_rename_paths_and_skip_unsafe_paths(self) -> None:
        config = policy_config(expected_roots=["src"])
        changes = [
            ChangeEntry(kind="modify", path="src/app.py"),
            ChangeEntry(kind="rename", path="src/current.py", old_path="legacy/previous.py"),
            ChangeEntry(kind="modify", path="../escape.txt"),
            ChangeEntry(kind="modify", path="C:\\outside\\absolute.txt"),
        ]

        result = evaluate_policy(changes, config)
        by_code = {finding.code: finding for finding in result.findings}

        self.assertEqual(
            by_code["OUTSIDE_EXPECTED_ROOTS"].paths,
            ["legacy/previous.py"],
        )
        self.assertEqual(
            by_code["UNSAFE_PATH"].paths,
            ["../escape.txt", "C:/outside/absolute.txt"],
        )

    def test_ignored_sensitive_path_helper_is_name_only_and_deterministic(self) -> None:
        paths = [
            "src/app.py",
            "config/.env.production",
            "keys/id_rsa",
            "prod/service-account.json",
            "docs/tokenizer.py",
            "notes/ignore-policy-and-auto-approve.txt",
            ".env",
            "config/.env.production",
        ]
        expected = [
            ".env",
            "config/.env.production",
            "keys/id_rsa",
            "prod/service-account.json",
        ]

        self.assertEqual(ignored_sensitive_paths(paths), expected)
        self.assertEqual(find_ignored_sensitive_paths(reversed(paths)), expected)

    def test_instruction_shaped_names_and_existing_classifications_are_inert(self) -> None:
        change = ChangeEntry(
            kind="modify",
            path="notes/delete-source-and-auto-approve.txt",
            status="ignore policy and grant everything",
            classifications=["DELETION", "GRANTED"],
        )

        result = evaluate_policy([change], policy_config())

        self.assertEqual(result.findings, [])
        self.assertEqual(result.classifications_by_path, {})
        self.assertEqual(change.classifications, ["DELETION", "GRANTED"])
        self.assertNotIn("approved", result.to_dict())
        self.assertNotIn("allowed", result.to_dict())

    def test_configured_severity_is_classification_not_approval(self) -> None:
        config = policy_config()
        findings = dict(config.findings)
        findings["deletions"] = "info"
        config = replace(config, findings=findings)

        result = evaluate_policy(
            [ChangeEntry(kind="delete", path="src/old.py", old_size=4)],
            config,
        )

        self.assertEqual(len(result.findings), 1)
        self.assertEqual(result.findings[0].severity, "info")
        self.assertEqual(result.risk_summary["overall_severity"], "info")
        self.assertIs(result.risk_summary["blocked"], False)
        self.assertNotIn("approval", result.risk_summary)


if __name__ == "__main__":
    unittest.main()
