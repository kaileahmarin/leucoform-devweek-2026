from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtCore import QSettings
    from PySide6.QtWidgets import QApplication
except ImportError as exc:  # pragma: no cover - Core-only environments intentionally skip Qt.
    raise unittest.SkipTest("PySide6 desktop extra is not installed") from exc

from notug_protocol.desktop.main import ActiveReview, MainWindow, OrbWidget
from notug_protocol.desktop.state import OrbState
from notug_protocol.errors import NoTugError


class DesktopQtTests(unittest.TestCase):
    app: QApplication

    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="leucoform-qt-")
        self.settings = QSettings(
            str(Path(self.temporary.name) / "settings.ini"),
            QSettings.Format.IniFormat,
        )
        with patch(
            "notug_protocol.desktop.main.discover_codex",
            side_effect=NoTugError("CODEX_NOT_FOUND", "not configured"),
        ):
            self.window = MainWindow(self.settings, tray_available=False)

    def tearDown(self) -> None:
        self.window.close()
        self.settings.clear()
        self.settings.sync()
        self.temporary.cleanup()

    def test_composer_has_keyboard_and_screen_reader_labels(self) -> None:
        self.assertEqual(self.window.prompt.accessibleName(), "Codex prompt")
        self.assertEqual(
            self.window.transfer_ack.accessibleName(),
            "Provider data transfer acknowledgement",
        )
        self.assertIn("Leucoform", self.window.windowTitle())
        self.assertFalse(self.window.cancel_button.isEnabled())
        self.assertEqual(self.window._validate_composer(), "Choose a valid Git repository.")

    def test_review_exposes_three_face_ceremony_without_hash_entry(self) -> None:
        tug_hash = "a" * 64
        self.window.active_review = ActiveReview("session_test", "tug_test", tug_hash)
        self.window.deny_button.setEnabled(True)
        self.window.grant_button.setEnabled(True)
        self.window._begin_grant_ceremony()
        self.assertEqual(self.window._state, OrbState.REVIEW)
        self.assertFalse(hasattr(self.window, "grant_phrase"))

    def test_orb_exposes_glyph_label_and_reduced_motion(self) -> None:
        orb = OrbWidget(self.settings)
        try:
            orb.set_state(OrbState.REVIEW)
            self.assertEqual(
                orb.accessibleDescription(),
                "Human review required; three-part Grant ceremony available",
            )
            self.assertTrue(all(not button.isHidden() for button in orb.consent_faces))
            orb.set_reduced_motion(True)
            self.assertTrue(orb.canvas.reduced_motion)
            self.assertTrue(self.settings.value("ui/reduced_motion", type=bool))
        finally:
            orb.close()

    def test_three_distinct_faces_are_required_in_order(self) -> None:
        orb = OrbWidget(self.settings)
        completions: list[bool] = []
        orb.consent_completed.connect(lambda: completions.append(True))
        try:
            orb.set_state(OrbState.REVIEW)
            first, second, third = orb.consent_faces
            orb._select_face(second)
            self.assertFalse(second.selected)
            orb._select_face(first)
            orb._select_face(first)
            self.assertEqual(completions, [])
            orb._select_face(second)
            orb._select_face(third)
            self.assertEqual(completions, [True])
            self.assertTrue(all(face.selected for face in orb.consent_faces))
        finally:
            orb.close()

    def test_companion_size_is_clamped_to_accessible_range(self) -> None:
        self.settings.setValue("ui/companion_size", 999)
        orb = OrbWidget(self.settings)
        try:
            self.assertEqual(orb.width(), 300)
            self.assertEqual(orb.height(), 300)
        finally:
            orb.close()


if __name__ == "__main__":
    unittest.main()
