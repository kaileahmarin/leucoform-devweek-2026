from __future__ import annotations

import unittest

from notug_protocol.submission import sanitize_dependency_inventory


class SubmissionPrivacyTests(unittest.TestCase):
    def test_dependency_inventory_removes_local_install_provenance(self) -> None:
        sanitized = sanitize_dependency_inventory(
            {
                "installed": [
                    {
                        "metadata": {"name": "example", "version": "1"},
                        "metadata_location": "X:/Users/person/project/.venv/site-packages/example",
                        "direct_url": {"url": "file:///X:/Users/person/project"},
                    }
                ]
            }
        )
        package = sanitized["installed"][0]
        self.assertNotIn("metadata_location", package)
        self.assertNotIn("direct_url", package)

    def test_dependency_inventory_rejects_profile_path_in_unexpected_field(self) -> None:
        with self.assertRaisesRegex(ValueError, "private path marker"):
            sanitize_dependency_inventory({"unexpected": "C:/Users/person/private"})


if __name__ == "__main__":
    unittest.main()
