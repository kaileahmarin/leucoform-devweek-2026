from __future__ import annotations

import os
import tempfile
import unittest
from collections.abc import Callable
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from notug_protocol import grants, sessions, tug
from notug_protocol.errors import NoTugError
from notug_protocol.events import EventVerification
from notug_protocol.vault import Vault


class TrackingVault:
    def __init__(self) -> None:
        self.root = Path("vault")
        self.events: list[tuple[str, str]] = []

    def ensure_external(self, _repository_root: Path) -> None:
        return

    @contextmanager
    def locked(self, repository_id: str):  # type: ignore[no-untyped-def]
        self.events.append(("enter", repository_id))
        try:
            yield
        finally:
            self.events.append(("exit", repository_id))


class TransitionLockingTests(unittest.TestCase):
    repository_id = "repo_exact"

    def assert_helper_runs_locked(self, vault: TrackingVault) -> object:
        self.assertEqual(vault.events, [("enter", self.repository_id)])
        return self

    def helper_for(self, vault: TrackingVault) -> Callable[..., object]:
        def helper(*_args: object, **_kwargs: object) -> object:
            return self.assert_helper_runs_locked(vault)

        return helper

    def test_initialize_serializes_receipt_verification_and_first_append(self) -> None:
        vault = TrackingVault()
        vault.ensure = Mock()  # type: ignore[attr-defined]
        vault.register_repository = Mock(  # type: ignore[attr-defined]
            return_value=SimpleNamespace(
                repository_id=self.repository_id,
                repository_key="e" * 64,
            )
        )
        vault.policy_path = Mock(return_value=Path("policy.toml"))  # type: ignore[attr-defined]
        vault.manifest_path = Mock(return_value=Path("manifest.json"))  # type: ignore[attr-defined]
        repository = SimpleNamespace(root=Path("repository"), head="a" * 40)
        policy = SimpleNamespace(sha256="b" * 64)
        manifest = SimpleNamespace(manifest_hash="c" * 64)
        ledger = Mock()
        ledger.verify.return_value = SimpleNamespace(count=0, head_hash=None)

        def append(**_kwargs: object) -> dict[str, str]:
            self.assertEqual(vault.events, [("enter", self.repository_id)])
            return {"event_hash": "d" * 64}

        ledger.append.side_effect = append
        with (
            patch.object(sessions, "discover_repository", return_value=repository),
            patch.object(sessions, "require_clean"),
            patch.object(sessions, "create_or_load_policy", return_value=policy),
            patch.object(sessions, "generate_manifest", return_value=manifest),
            patch.object(sessions, "write_manifest"),
            patch.object(sessions, "ledger_for", return_value=ledger),
            patch.object(sessions, "repository_metadata_hash", return_value="f" * 64),
        ):
            result = sessions.initialize_repository(Path("repository"), vault)  # type: ignore[arg-type]

        self.assertEqual(result.receipt_head, "d" * 64)
        self.assertEqual(
            vault.events,
            [("enter", self.repository_id), ("exit", self.repository_id)],
        )

    def test_session_start_rejects_registration_without_initialization_receipt(self) -> None:
        vault = Mock()
        vault.find_repository.return_value = SimpleNamespace(repository_id=self.repository_id)
        ledger = Mock()
        ledger.verify.return_value = EventVerification(0, None, (), 0)
        with (
            patch.object(sessions, "ledger_for", return_value=ledger),
            self.assertRaises(NoTugError) as caught,
        ):
            sessions._ensure_initialized(SimpleNamespace(), vault)
        self.assertEqual(caught.exception.code, "REPOSITORY_INITIALIZATION_INCOMPLETE")

    def test_run_command_serializes_entire_operation(self) -> None:
        vault = TrackingVault()
        helper = Mock(side_effect=self.helper_for(vault))
        with (
            patch.object(sessions, "find_session", return_value=(self.repository_id, {})),
            patch.object(sessions, "_run_agent_command_locked", helper),
        ):
            result = sessions.run_agent_command("session_exact", ["agent"], vault)  # type: ignore[arg-type]

        self.assertIs(result, self)
        helper.assert_called_once_with("session_exact", ["agent"], vault)
        self.assertEqual(vault.events[-1], ("exit", self.repository_id))

    def test_archive_serializes_entire_operation(self) -> None:
        vault = TrackingVault()
        helper = Mock(side_effect=self.helper_for(vault))
        with (
            patch.object(sessions, "find_session", return_value=(self.repository_id, {})),
            patch.object(sessions, "_archive_session_locked", helper),
        ):
            result = sessions.archive_session("session_exact", vault)  # type: ignore[arg-type]

        self.assertIsNone(result)
        helper.assert_called_once_with("session_exact", vault)
        self.assertEqual(vault.events[-1], ("exit", self.repository_id))

    def test_generate_and_deny_serialize_tug_transitions(self) -> None:
        for public, locator, private, identifier in (
            (tug.generate_tug, "find_session", "_generate_tug_locked", "session_exact"),
            (tug.deny_tug, "find_tug", "_deny_tug_locked", "tug_exact"),
        ):
            with self.subTest(operation=public.__name__):
                vault = TrackingVault()
                helper = Mock(side_effect=self.helper_for(vault))
                with (
                    patch.object(tug, locator, return_value=(self.repository_id, {})),
                    patch.object(tug, private, helper),
                ):
                    result = public(identifier, vault)  # type: ignore[arg-type]

                self.assertIs(result, self)
                helper.assert_called_once_with(identifier, vault)
                self.assertEqual(vault.events[-1], ("exit", self.repository_id))

    def test_grant_serializes_transition_without_an_unattended_seam(self) -> None:
        vault = TrackingVault()
        helper = Mock(side_effect=self.helper_for(vault))
        with (
            patch.object(grants, "_assert_human_context"),
            patch.object(grants, "find_tug", return_value=(self.repository_id, {})),
            patch.object(grants, "_grant_tug_locked", helper),
        ):
            result = grants.grant_tug("tug_exact", vault)  # type: ignore[arg-type]

        self.assertIs(result, self)
        helper.assert_called_once_with("tug_exact", vault)
        self.assertEqual(vault.events[-1], ("exit", self.repository_id))

    def test_revoke_serializes_entire_transition(self) -> None:
        vault = TrackingVault()
        helper = Mock(side_effect=self.helper_for(vault))
        with (
            patch.object(grants, "find_grant_for_tug", return_value=(self.repository_id, {})),
            patch.object(grants, "_revoke_grant_locked", helper),
        ):
            result = grants.revoke_grant("tug_exact", vault)  # type: ignore[arg-type]

        self.assertIs(result, self)
        helper.assert_called_once_with("tug_exact", vault)
        self.assertEqual(vault.events[-1], ("exit", self.repository_id))

    def test_grant_rejects_validation_and_every_managed_worktree_context(self) -> None:
        with tempfile.TemporaryDirectory(prefix="notug-grant-context-") as temporary:
            vault = Vault(Path(temporary) / "v1")
            with (
                patch.dict(os.environ, {"NOTUG_VALIDATION_CONTEXT": "1"}),
                self.assertRaises(NoTugError) as validation_error,
            ):
                grants._assert_human_context(vault)
            self.assertEqual(validation_error.exception.code, "GRANT_FROM_AGENT_CONTEXT")

            managed = vault.worktrees_dir / "repo_example" / "i" / "grant_example"
            managed.mkdir(parents=True)
            with (
                patch.object(grants.Path, "cwd", return_value=managed),
                self.assertRaises(NoTugError) as worktree_error,
            ):
                grants._assert_human_context(vault)
            self.assertEqual(worktree_error.exception.code, "GRANT_FROM_AGENT_CONTEXT")


if __name__ == "__main__":
    unittest.main()
