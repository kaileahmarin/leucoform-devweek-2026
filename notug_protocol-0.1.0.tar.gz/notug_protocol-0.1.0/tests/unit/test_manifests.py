from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

from notug_protocol.errors import NoTugError
from notug_protocol.identity import new_identifier
from notug_protocol.manifests import (
    BaselineManifest,
    generate_manifest,
    load_manifest,
    verify_manifest,
    write_manifest,
)


class ManifestTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="notug-manifest-")
        self.root = Path(self.temporary.name) / "repo"
        self.root.mkdir()
        self.git("init", "--initial-branch=main")
        self.git("config", "user.name", "NoTUG Test")
        self.git("config", "user.email", "notug@example.invalid")
        (self.root / "alpha.txt").write_bytes(b"alpha\n")
        (self.root / "binary.bin").write_bytes(b"\x00\x01\xffbinary\x00")
        self.git("add", "--", "alpha.txt", "binary.bin")
        self.git("commit", "-m", "baseline")
        self.repository_id = new_identifier("repo")

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def git(self, *arguments: str, input_bytes: bytes | None = None) -> bytes:
        completed = subprocess.run(
            ("git", "-C", str(self.root), *arguments),
            input=input_bytes,
            capture_output=True,
            check=False,
            shell=False,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        if completed.returncode != 0:
            self.fail(completed.stderr.decode("utf-8", errors="replace"))
        return completed.stdout

    def assert_code(self, expected: str, operation: object) -> None:
        with self.assertRaises(NoTugError) as caught:
            if callable(operation):
                operation()
        self.assertEqual(caught.exception.code, expected)

    def test_manifest_hashes_exact_blob_bytes_and_is_deterministic(self) -> None:
        first = generate_manifest(self.root, repository_id=self.repository_id)
        second = generate_manifest(self.root, repository_id=self.repository_id)
        self.assertEqual(first.manifest_hash, second.manifest_hash)
        self.assertEqual(first.commit, second.commit)
        entries = {entry.path: entry for entry in first.entries}
        self.assertEqual(entries["alpha.txt"].sha256, hashlib.sha256(b"alpha\n").hexdigest())
        self.assertEqual(
            entries["binary.bin"].sha256,
            hashlib.sha256(b"\x00\x01\xffbinary\x00").hexdigest(),
        )
        self.assertEqual(entries["binary.bin"].size, 10)

    def test_manifest_is_bound_to_commit_not_later_worktree_edits(self) -> None:
        manifest = generate_manifest(self.root, repository_id=self.repository_id)
        (self.root / "alpha.txt").write_bytes(b"uncommitted mutation\n")
        rebuilt = verify_manifest(self.root, manifest)
        self.assertEqual(rebuilt.manifest_hash, manifest.manifest_hash)
        alpha = next(entry for entry in rebuilt.entries if entry.path == "alpha.txt")
        self.assertEqual(alpha.sha256, hashlib.sha256(b"alpha\n").hexdigest())

    def test_write_load_and_unknown_field_rejection(self) -> None:
        manifest = generate_manifest(self.root, repository_id=self.repository_id)
        path = Path(self.temporary.name) / "manifest.json"
        write_manifest(path, manifest)
        self.assertEqual(load_manifest(path).manifest_hash, manifest.manifest_hash)
        value = json.loads(path.read_text(encoding="utf-8"))
        value["unexpected"] = True
        path.write_text(json.dumps(value), encoding="utf-8")
        self.assert_code("MANIFEST_INVALID", lambda: load_manifest(path))

    def test_altered_manifest_hash_fails_closed(self) -> None:
        manifest = generate_manifest(self.root, repository_id=self.repository_id)
        value = manifest.to_dict()
        value["manifest_hash"] = "0" * 64
        self.assert_code("MANIFEST_HASH_MISMATCH", lambda: BaselineManifest.from_dict(value))

    def test_manifest_substitution_is_rejected_by_expected_vault_identity(self) -> None:
        first = generate_manifest(self.root, repository_id=self.repository_id)
        (self.root / "later.txt").write_bytes(b"later baseline\n")
        self.git("add", "later.txt")
        self.git("commit", "-m", "later baseline")
        second = generate_manifest(self.root, repository_id=self.repository_id)
        first_path = Path(self.temporary.name) / f"{first.manifest_hash}.json"
        second_path = Path(self.temporary.name) / f"{second.manifest_hash}.json"
        write_manifest(first_path, first)
        write_manifest(second_path, second)
        first_path.write_bytes(second_path.read_bytes())

        self.assert_code(
            "MANIFEST_ID_MISMATCH",
            lambda: load_manifest(
                first_path,
                expected_hash=first_path.stem,
                expected_repository_id=self.repository_id,
            ),
        )

    def test_symlink_and_gitlink_modes_are_evidenced_without_checkout_support(self) -> None:
        baseline = self.git("rev-parse", "HEAD").decode("ascii").strip()
        symlink_blob = self.git("hash-object", "-w", "--stdin", input_bytes=b"../outside")
        symlink_oid = symlink_blob.decode("ascii").strip()
        self.git("update-index", "--add", "--cacheinfo", f"120000,{symlink_oid},outside-link")
        self.git("update-index", "--add", "--cacheinfo", f"160000,{baseline},vendor/dependency")
        self.git("commit", "-m", "add structural entries")
        manifest = generate_manifest(self.root, repository_id=self.repository_id)
        entries = {entry.path: entry for entry in manifest.entries}
        self.assertEqual(entries["outside-link"].kind, "symlink")
        self.assertEqual(entries["outside-link"].mode, "120000")
        self.assertEqual(entries["outside-link"].sha256, hashlib.sha256(b"../outside").hexdigest())
        self.assertEqual(entries["vendor/dependency"].kind, "submodule")
        self.assertEqual(entries["vendor/dependency"].mode, "160000")
        self.assertEqual(entries["vendor/dependency"].git_oid, baseline)

    def test_case_colliding_manifest_paths_are_rejected(self) -> None:
        manifest = generate_manifest(self.root, repository_id=self.repository_id)
        value = manifest.to_dict()
        entry = dict(value["entries"][0])
        entry["path"] = entry["path"].swapcase()
        value["entries"].append(entry)
        value["entries"] = sorted(value["entries"], key=lambda child: child["path"])
        # Path collision precedes the envelope hash, which is the intended fail-closed order.
        self.assert_code("WINDOWS_PATH_COLLISION", lambda: BaselineManifest.from_dict(value))


if __name__ == "__main__":
    unittest.main()
