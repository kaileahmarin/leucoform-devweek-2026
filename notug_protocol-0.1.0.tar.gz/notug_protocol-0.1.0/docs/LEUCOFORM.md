# Leucoform desktop companion

Leucoform is the human-facing desktop product powered by the NoTUG Core. It is an optional PySide6 Qt Widgets adapter: installing or using plain `notug` keeps the Core dependency-free.

## Authority and privacy boundary

Leucoform calls typed application services for repository initialization, session creation/listing, managed execution, Tug generation/review, exact native grant, denial, clean abandonment, and explicit archival. The native grant phrase is passed to a Core-owned callback path. Under the repository transition lock, Core repeats agent-context rejection, receipt-chain verification, strict Tug/hash validation, policy and baseline checks, repository drift checks, and safe-apply preflight before an integration branch can exist.

The Agent Bridge does not expose this callback or any grant authority. The CLI retains its TTY-only ceremony. Neither adapter can merge, push, publish, or switch the protected checkout.

Leucoform stores only recent repository paths, selected Codex path, orb position, reduced-motion preference, and UI preferences through platform-native Qt settings. Prompts are held only long enough to write bounded UTF-8 bytes to child stdin. They are not included in argv, operation records, receipts, settings, or process listings. Normalized activity is bounded in memory and is not persisted as a raw JSONL transcript.

Codex and the configured AI provider can use the network. Leucoform requires an explicit provider data-transfer acknowledgement for every run. Leucoform itself contains no telemetry, updater, background network check, Codex downloader, or bundled Codex copy.

## Experience

The floating orb is draggable and snaps to the nearest screen corner. It uses colour, a glyph, accessible text, and tray/menu-bar status:

| State | Colour | Non-colour cue | Meaning |
|---|---|---|---|
| Idle | Slate | open circle | no active protected work |
| Ready | Cyan | diamond | protected session ready |
| Working | Blue | play glyph | Codex is running |
| Verifying | Violet | filled diamond | evidence is freezing or being revalidated |
| Review | Amber | exclamation and optional pulse | a human decision is required |
| Integrated | Green | check | integration branch and receipt were verified |
| Alert | Red | cross | divergence, verification failure, or interrupted evidence |

Reduced motion disables the amber pulse. Keyboard focus follows native widget order; composer, acknowledgement, activity, review, ceremony, and status controls have screen-reader names. System palette colours support dark and high-contrast themes, while state meaning never depends on colour alone. Offscreen/minimal Qt platforms and `LEUCOFORM_COMPACT_WINDOW=1` use a normal compact window instead of transparency.

Only one Leucoform instance and one Leucoform-launched agent run are supported at a time. A second launch activates the existing instance through a local same-user Qt socket.

## Run and recovery lifecycle

1. The user picks a Git repository and explicitly enables NoTUG protection if required.
2. Leucoform verifies a local Codex version, takes a prompt, and requires the provider-transfer acknowledgement.
3. Core creates the exact managed worktree. The runner invokes the equivalent of `codex -C WORKTREE --ask-for-approval never exec --ephemeral --sandbox workspace-write --json --color never -` without a shell.
4. JSONL stdout is normalized for bounded live progress. Cancellation terminates the child and records `RUN_CANCELLED`; a process failure records `RUN_FAILED`.
5. Successful changed work is automatically frozen into a Tug. Unchanged work can be explicitly marked `ABANDONED`. Failed, cancelled, or partial work remains available for retry, review/freeze, denial, or retention.
6. Review shows affected paths, sanitized diff, line/byte totals, policy findings, risk, full Tug hash, protected baseline, and receipt verification.
7. Grant requires the complete `GRANT <64-hex-hash>` phrase. Denial requires confirmation. Archival is a separate action after grant, denial, or abandonment.

A crash does not fabricate a cancellation receipt. An interrupted in-flight operation remains incomplete evidence for verification and recovery; Leucoform does not automatically rewrite it.

## Packaging

PyInstaller builds run natively on each operating system. Windows uses Inno Setup for `Leucoform-Setup.exe`; macOS places `Leucoform.app` in `Leucoform.dmg`; Linux produces `Leucoform.AppImage` and a Debian package. Native scripts run Core/desktop tests and a frozen offscreen self-test, capture `pip inspect` as an SBOM, copy notices, and hash output. The CI workflow is manually dispatched and uploads unsigned development artifacts rather than publishing a release.

Signing, notarization, and package signing are release-operator steps only when credentials are supplied. Package-content and license review remain required before a public release.
