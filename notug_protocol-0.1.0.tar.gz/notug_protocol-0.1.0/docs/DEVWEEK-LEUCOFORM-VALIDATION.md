# Leucoform DevWeek validation log

Date: 2026-07-20  
Host: Windows 11, Python 3.12.13  
Scope: local source, native Windows development packaging, no publication

## Event log

1. Preserved the existing dirty `feature/agent-bridge-foundation` worktree and its earlier bridge correction pass. No commit, merge, push, tag, or publication was performed.
2. Added Core-owned exact-phrase grant confirmation while retaining the CLI TTY provider. Agent-context rejection and locked Tug/baseline/policy/receipt revalidation remain shared. Agent Bridge received no grant capability.
3. Added bounded stdin streaming, cancellable child execution, `RUN_CANCELLED`, explicit clean `ABANDONED`, typed desktop services, and receipt verification coverage.
4. Implemented the optional PySide6 Leucoform orb, tray fallback, composer, local Codex discovery/version display, normalized JSONL activity, recovery controls, review, native phrase field, denial, and explicit archival.
5. Verified local Codex discovery as `codex-cli 0.144.6` through the official npm Node entry point. No live provider prompt was sent during this implementation run.
6. Focused Core/UI gates passed, followed by the complete suite: `179 passed in 282.70s`.
7. Ruff formatting/lint, strict mypy, documentation links, receipt minimisation, and `git diff --check` passed. The minimisation scan rejected 18 prohibited receipt fields.
8. Native Windows dark/high-DPI composer and review renders were inspected. The normal Qt offscreen driver had no font database, so native Windows rendering supplied visual evidence while offscreen Qt remained the deterministic behavior harness.
9. PyInstaller created a windowed 45,718,759-byte `Leucoform.exe`. The archive contains the MIT license and third-party notices, and contains no Codex executable. Its frozen `--self-test` exited 0.
10. Inno Setup 6.7.3 created `Leucoform-Setup.exe`. A silent install into an isolated test folder exited 0, the installed app self-test exited 0, the generated uninstaller exited 0, and the install folder no longer existed afterward.
11. The source wheel and sdist passed exact-content, metadata, GUI-entry-point, fresh-install, and demo verification. No artifacts were uploaded.
12. A UTF-8 JSON SBOM and SHA-256 manifest were generated for the local Windows development artifacts.

## Artifact hashes

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `dist/installer/Leucoform-Setup.exe` | 47,359,299 | `c802cdb89de2986e0f66a6cd299385b5275b80dc0bbb8f5c3d97a5d404ef97a4` |
| `dist/Leucoform.exe` | 45,721,131 | `8ab49c33f3313c1b5857441154490461903d75ebf5e79d044afe99ac9bb37a77` |

## Honest platform boundary

Windows source behavior, native rendering, frozen startup, setup install, and uninstall were exercised on this host. macOS DMG and Linux AppImage/deb definitions and manually dispatched native CI jobs are implemented but were not executed from Windows. Those artifacts remain development candidates until their native jobs, visual QA, install/uninstall checks, package-content inspection, and signing decisions complete.
